# Build the APK with GitHub (no Android Studio)

1. Upload: on github.com create a repository, then "Add file > Upload files" and drag in everything
   from inside the WhatsAppMessageVault folder (a computer browser works best). Make sure the
   folders ".github", "app" and "gradle" and the files build.gradle.kts, settings.gradle.kts,
   gradle.properties are included. Press "Commit changes".
2. Run: Actions tab > "Build APK" > Run workflow > Run workflow. Wait 5-10 minutes for a green tick.
3. Download: open the finished run, scroll to "Artifacts", tap WhatsAppMessageVault-debug-apk (a zip).
   Unzip it, tap app-debug.apk, allow "install unknown apps", Install.
If the run shows a red X, open it and send me the error text.
