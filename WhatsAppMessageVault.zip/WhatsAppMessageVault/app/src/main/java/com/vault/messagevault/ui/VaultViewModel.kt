package com.vault.messagevault.ui

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vault.messagevault.data.ConvSummary
import com.vault.messagevault.data.MessageEntity
import com.vault.messagevault.data.VaultDatabase
import com.vault.messagevault.service.VaultListenerService
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

sealed interface Screen {
    object Setup : Screen
    object Home : Screen
    data class Conversation(val key: String, val title: String) : Screen
    object Xiaomi : Screen
    object Settings : Screen
}

enum class TestState { Idle, Running, Ok, Failed, NoPermission }

@OptIn(ExperimentalCoroutinesApi::class)
class VaultViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = VaultDatabase.get(app).dao()
    private val prefs = app.getSharedPreferences("vault", Context.MODE_PRIVATE)

    var screen: Screen by mutableStateOf(
        if (prefs.getBoolean("setup_done", false)) Screen.Home else Screen.Setup
    )
        private set
    private var previous: Screen = Screen.Home

    var testState by mutableStateOf(TestState.Idle)
    var setupStep by mutableStateOf(1)

    val query = MutableStateFlow("")
    val convFilter = MutableStateFlow("")
    val range = MutableStateFlow(0) // 0 all, 1 today, 2 last 7 days, 3 last 30 days
    private val openConv = MutableStateFlow("")

    val messages: StateFlow<List<MessageEntity>> =
        combine(query, convFilter, range) { q, c, r -> Triple(q, c, r) }
            .flatMapLatest { (q, c, r) -> dao.search(q.trim(), c, fromTs(r)) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val convMessages: StateFlow<List<MessageEntity>> =
        openConv.flatMapLatest { dao.forConversation(it) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val conversations: StateFlow<List<ConvSummary>> =
        dao.conversations().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val total = dao.countAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val deleted = dao.countDeleted().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val changed = dao.countChanged().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private fun fromTs(r: Int): Long {
        val now = System.currentTimeMillis()
        return when (r) {
            1 -> Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            2 -> now - 7L * 24 * 3600 * 1000
            3 -> now - 30L * 24 * 3600 * 1000
            else -> 0L
        }
    }

    fun go(to: Screen) {
        if (to is Screen.Conversation) openConv.value = to.key
        if (screen !is Screen.Xiaomi && screen !is Screen.Settings) previous = screen
        screen = to
    }

    fun back() {
        screen = if (previous is Screen.Conversation) Screen.Home else previous
        previous = Screen.Home
    }

    fun restartSetup() { setupStep = 1; screen = Screen.Setup; testState = TestState.Idle }

    fun finishSetup() {
        prefs.edit().putBoolean("setup_done", true).apply()
        screen = Screen.Home
    }

    fun deleteRecord(id: Long) = viewModelScope.launch { dao.deleteById(id) }
    fun deleteConversation(key: String) = viewModelScope.launch {
        dao.deleteConversation(key)
        if (convFilter.value == key) convFilter.value = ""
    }
    fun deleteAll() = viewModelScope.launch { dao.deleteAll(); convFilter.value = "" }

    /** Posts a harmless notification from this app itself and checks that the listener sees it. */
    @SuppressLint("MissingPermission")
    fun runTest(ctx: Context) {
        testState = TestState.Running
        VaultListenerService.testReceived.value = false
        val nm = NotificationManagerCompat.from(ctx)
        nm.createNotificationChannel(
            NotificationChannelCompat.Builder("vault_test", NotificationManagerCompat.IMPORTANCE_LOW)
                .setName("Setup test").build()
        )
        val extras = Bundle().apply { putBoolean(VaultListenerService.EXTRA_TEST, true) }
        val n = NotificationCompat.Builder(ctx, "vault_test")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Message Vault test")
            .setContentText("This is only a test. Nothing is saved.")
            .addExtras(extras)
            .setTimeoutAfter(15000)
            .build()
        try {
            nm.notify(9001, n)
        } catch (e: SecurityException) {
            testState = TestState.NoPermission
            return
        }
        viewModelScope.launch {
            var i = 0
            while (i < 20 && !VaultListenerService.testReceived.value) { delay(500); i++ }
            testState = if (VaultListenerService.testReceived.value) TestState.Ok else TestState.Failed
            nm.cancel(9001)
        }
    }
}
