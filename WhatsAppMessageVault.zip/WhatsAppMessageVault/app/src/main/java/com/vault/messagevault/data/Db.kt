package com.vault.messagevault.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "messages",
    indices = [Index("convKey"), Index("capturedAt")]
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val convKey: String,
    val convTitle: String,
    val groupName: String?,
    val sender: String,
    val title: String,
    val text: String,
    val msgTs: Long,
    val capturedAt: Long,
    val dayKey: String,
    val category: String,
    /** NORMAL, CHANGED (different text for the same message) or DELETED (WhatsApp deletion notice) */
    val kind: String,
    val relatedId: Long? = null,
    /** Permanent copy of the earlier text, kept on CHANGED / DELETED records. */
    val relatedText: String? = null,
    val wasDeleted: Boolean = false,
    val wasEdited: Boolean = false
)

data class ConvSummary(val convKey: String, val convTitle: String, val cnt: Int, val last: Long)

@Dao
interface MessageDao {
    @Insert suspend fun insert(m: MessageEntity): Long

    @Query("UPDATE messages SET wasDeleted = 1 WHERE id = :id") suspend fun markDeleted(id: Long)
    @Query("UPDATE messages SET wasEdited = 1 WHERE id = :id") suspend fun markEdited(id: Long)

    @Query("SELECT * FROM messages WHERE convKey = :c AND sender = :s AND text = :t AND msgTs = :ts LIMIT 1")
    suspend fun findExact(c: String, s: String, t: String, ts: Long): MessageEntity?

    @Query("SELECT * FROM messages WHERE convKey = :c AND sender = :s AND msgTs = :ts AND kind != 'DELETED' ORDER BY id DESC LIMIT 1")
    suspend fun findByTs(c: String, s: String, ts: Long): MessageEntity?

    @Query("SELECT * FROM messages WHERE convKey = :c AND kind != 'DELETED' AND wasDeleted = 0 ORDER BY id DESC LIMIT 1")
    suspend fun latestOriginal(c: String): MessageEntity?

    @Query("SELECT * FROM messages WHERE convKey = :c ORDER BY id DESC LIMIT 1")
    suspend fun latestInConv(c: String): MessageEntity?

    @Query(
        """SELECT * FROM messages WHERE
        (:q = '' OR text LIKE '%' || :q || '%' OR sender LIKE '%' || :q || '%'
            OR convTitle LIKE '%' || :q || '%' OR groupName LIKE '%' || :q || '%'
            OR dayKey LIKE '%' || :q || '%')
        AND (:conv = '' OR convKey = :conv)
        AND capturedAt >= :from
        ORDER BY capturedAt DESC, id DESC LIMIT 1000"""
    )
    fun search(q: String, conv: String, from: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE convKey = :c ORDER BY capturedAt ASC, id ASC")
    fun forConversation(c: String): Flow<List<MessageEntity>>

    @Query("SELECT convKey, convTitle, COUNT(*) AS cnt, MAX(capturedAt) AS last FROM messages GROUP BY convKey ORDER BY last DESC")
    fun conversations(): Flow<List<ConvSummary>>

    @Query("SELECT COUNT(*) FROM messages") fun countAll(): Flow<Int>
    @Query("SELECT COUNT(*) FROM messages WHERE kind = 'DELETED'") fun countDeleted(): Flow<Int>
    @Query("SELECT COUNT(*) FROM messages WHERE kind = 'CHANGED'") fun countChanged(): Flow<Int>

    @Query("DELETE FROM messages WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("DELETE FROM messages WHERE convKey = :c") suspend fun deleteConversation(c: String)
    @Query("DELETE FROM messages") suspend fun deleteAll()
}

@Database(entities = [MessageEntity::class], version = 1, exportSchema = false)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun dao(): MessageDao

    companion object {
        @Volatile private var instance: VaultDatabase? = null
        fun get(context: Context): VaultDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, VaultDatabase::class.java, "vault.db"
            ).build().also { instance = it }
        }
    }
}
