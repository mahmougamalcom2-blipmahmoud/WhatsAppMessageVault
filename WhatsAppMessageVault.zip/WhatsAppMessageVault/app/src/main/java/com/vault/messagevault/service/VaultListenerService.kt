package com.vault.messagevault.service

import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.vault.messagevault.data.VaultDatabase
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Read-only listener: it only reads WhatsApp notifications. It never replies, dismisses or opens anything. */
class VaultListenerService : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()

    override fun onListenerConnected() {
        connected.value = true
    }

    override fun onListenerDisconnected() {
        connected.value = false
        try {
            NotificationListenerService.requestRebind(ComponentName(this, VaultListenerService::class.java))
        } catch (_: Exception) {
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) {
            if (sbn.notification.extras.getBoolean(EXTRA_TEST, false)) testReceived.value = true
            return
        }
        if (sbn.packageName !in WHATSAPP_PACKAGES) return
        val drafts = try { NotificationParser.parse(sbn) } catch (_: Exception) { emptyList() }
        if (drafts.isEmpty()) return
        val dao = VaultDatabase.get(applicationContext).dao()
        scope.launch {
            mutex.withLock {
                for (d in drafts) {
                    try { Recorder.record(dao, d) } catch (_: Exception) { }
                }
            }
        }
    }

    override fun onDestroy() {
        connected.value = false
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TEST = "vault_self_test"
        val connected = MutableStateFlow(false)
        val testReceived = MutableStateFlow(false)
    }
}
