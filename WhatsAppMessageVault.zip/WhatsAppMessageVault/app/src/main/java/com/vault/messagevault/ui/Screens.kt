@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.vault.messagevault.ui

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vault.messagevault.data.MessageEntity
import com.vault.messagevault.service.VaultListenerService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF075E54)
private val Red = Color(0xFFB3261E)

data class SystemStatus(val accessGranted: Boolean, val batteryUnrestricted: Boolean)

fun readStatus(ctx: Context): SystemStatus {
    val access = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    return SystemStatus(access, pm.isIgnoringBatteryOptimizations(ctx.packageName))
}

private fun Context.openFirst(vararg intents: Intent): Boolean {
    for (i in intents) {
        try { startActivity(i); return true } catch (_: Exception) { }
    }
    return false
}

private fun Context.appDetails() = Intent(
    Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")
)

private fun fmt(ts: Long): String =
    SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(ts))

@Composable
fun App(vm: VaultViewModel) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val status = remember(tick) { readStatus(ctx) }
    val connected by VaultListenerService.connected.collectAsStateWithLifecycle()
    val screen = vm.screen

    BackHandler(enabled = screen is Screen.Conversation || screen is Screen.Xiaomi || screen is Screen.Settings) {
        vm.back()
    }

    when (screen) {
        Screen.Setup -> SetupScreen(vm, status, connected)
        Screen.Home -> HomeScreen(vm, status, connected)
        is Screen.Conversation -> ConversationScreen(vm, screen)
        Screen.Xiaomi -> XiaomiScreen(vm, status)
        Screen.Settings -> SettingsScreen(vm)
    }
}

// ---------------------------------------------------------------- Setup wizard

@Composable
fun SetupScreen(vm: VaultViewModel, status: SystemStatus, connected: Boolean) {
    val ctx = LocalContext.current
    val step = vm.setupStep
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.runTest(ctx) else vm.testState = TestState.NoPermission
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Setup - step $step of 4") }) }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (step) {
                1 -> {
                    Text("Welcome", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("This app saves WhatsApp notification content so you can keep a local history of notifications that may later disappear.")
                    Text("Everything stays on this phone. There is no account, no internet and no server.")
                    Text(
                        "Honest limit: the app can only keep what WhatsApp actually showed in a notification. " +
                            "It cannot recover messages that never appeared as a notification.",
                        color = Red
                    )
                    Button(onClick = {
                        ctx.openFirst(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }, Modifier.fillMaxWidth()) { Text("Enable Notification Access") }
                    Button(onClick = { vm.setupStep = 2 }, Modifier.fillMaxWidth()) { Text("Next") }
                }
                2 -> {
                    Text("Why is notification access needed?", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Android only lets an app read notifications if you switch this on. The app reads WhatsApp notifications only, never replies, never opens WhatsApp and never sends anything anywhere.")
                    StatusLine("Notification access", status.accessGranted)
                    if (!status.accessGranted) {
                        Text("In the list, tap \"WhatsApp Message Vault\" and switch it on.")
                        Button(onClick = {
                            ctx.openFirst(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }, Modifier.fillMaxWidth()) { Text("Open Notification Access settings") }
                        Text("If the switch is greyed out or says \"Restricted setting\" (common on Android 13+ for apps installed from a file): open App info, tap the three dots at the top right, choose \"Allow restricted settings\", then try again.")
                        OutlinedButton(onClick = { ctx.openFirst(ctx.appDetails()) }, Modifier.fillMaxWidth()) {
                            Text("Open App info")
                        }
                    }
                    Button(onClick = { vm.setupStep = 3 }, Modifier.fillMaxWidth()) { Text("Next") }
                }
                3 -> {
                    Text("Keep the app alive", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Xiaomi phones often stop background apps to save battery. That can make the app miss notifications.")
                    StatusLine("Battery optimization turned off for this app", status.batteryUnrestricted)
                    Button(onClick = {
                        ctx.openFirst(
                            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                            ctx.appDetails()
                        )
                    }, Modifier.fillMaxWidth()) { Text("Open battery settings") }
                    Button(onClick = { vm.go(Screen.Xiaomi) }, Modifier.fillMaxWidth()) {
                        Text("Xiaomi / MIUI Setup (recommended)")
                    }
                    Button(onClick = { vm.setupStep = 4 }, Modifier.fillMaxWidth()) { Text("Next") }
                }
                else -> {
                    Text("Test", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("The app will show a small test notification to itself and check that it can see it. Nothing is saved.")
                    Button(onClick = {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED
                        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        else vm.runTest(ctx)
                    }, Modifier.fillMaxWidth()) { Text("Run test") }
                    when (vm.testState) {
                        TestState.Idle -> {}
                        TestState.Running -> Text("Testing...")
                        TestState.Ok -> Text("Test passed.", color = Green, fontWeight = FontWeight.Bold)
                        TestState.Failed -> Text("The test notification was not seen. Check that Notification Access is ON (step 2) and try again.", color = Red)
                        TestState.NoPermission -> Text("The test needs permission to show a notification. You can skip it; the status below still checks the service.", color = Red)
                    }
                    val active = status.accessGranted && connected
                    if (active) {
                        Text("✅ WhatsApp notification monitoring is active", color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text("Monitoring is not active yet. Turn on Notification Access (step 2).", color = Red)
                    }
                    Button(onClick = { vm.finishSetup() }, Modifier.fillMaxWidth()) { Text("Finish") }
                }
            }
            if (step > 1) TextButton(onClick = { vm.setupStep = step - 1 }) { Text("Back") }
        }
    }
}

@Composable
private fun StatusLine(label: String, ok: Boolean) {
    Text(
        (if (ok) "✅ " else "⚠️ ") + label + (if (ok) ": OK" else ": not done"),
        color = if (ok) Green else Red, fontWeight = FontWeight.Medium
    )
}

// ---------------------------------------------------------------- Home

@Composable
fun HomeScreen(vm: VaultViewModel, status: SystemStatus, connected: Boolean) {
    val msgs by vm.messages.collectAsStateWithLifecycle()
    val total by vm.total.collectAsStateWithLifecycle()
    val deleted by vm.deleted.collectAsStateWithLifecycle()
    val changed by vm.changed.collectAsStateWithLifecycle()
    val convs by vm.conversations.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val convFilter by vm.convFilter.collectAsStateWithLifecycle()
    val range by vm.range.collectAsStateWithLifecycle()
    var menuOpen by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<MessageEntity?>(null) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("WhatsApp Message Vault", fontSize = 20.sp) },
            actions = {
                IconButton(onClick = { vm.go(Screen.Settings) }) { Icon(Icons.Default.Settings, "Settings") }
            }
        )
    }) { pad ->
        LazyColumn(
            Modifier.padding(pad), contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                if (!status.accessGranted) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFDECEA))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Notification access is OFF - nothing is being saved.", color = Red, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { vm.restartSetup() }) { Text("Open setup") }
                        }
                    }
                } else if (!connected) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4E5))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("The monitoring service is not running right now. Check the Xiaomi / MIUI settings.", color = Red)
                            TextButton(onClick = { vm.go(Screen.Xiaomi) }) { Text("Xiaomi / MIUI Setup") }
                        }
                    }
                } else {
                    Text("✅ Monitoring is active", color = Green, fontWeight = FontWeight.Medium)
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("Saved", total, Modifier.weight(1f))
                    Stat("Deleted", deleted, Modifier.weight(1f))
                    Stat("Changed", changed, Modifier.weight(1f))
                }
            }
            item {
                OutlinedTextField(
                    value = query, onValueChange = { vm.query.value = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    placeholder = { Text("Search messages, contact, group or date (2026-11-19)") }
                )
            }
            item {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        FilterChip(
                            selected = convFilter.isNotEmpty(), onClick = { menuOpen = true },
                            label = { Text(convs.firstOrNull { it.convKey == convFilter }?.convTitle ?: "All contacts") }
                        )
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("All contacts") }, onClick = {
                                vm.convFilter.value = ""; menuOpen = false
                            })
                            convs.forEach { c ->
                                DropdownMenuItem(text = { Text("${c.convTitle} (${c.cnt})") }, onClick = {
                                    vm.convFilter.value = c.convKey; menuOpen = false
                                })
                            }
                        }
                    }
                    listOf("Any date", "Today", "7 days", "30 days").forEachIndexed { i, label ->
                        FilterChip(selected = range == i, onClick = { vm.range.value = i }, label = { Text(label) })
                    }
                }
            }
            item { Text("Latest", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            if (msgs.isEmpty()) {
                item {
                    Text(
                        if (total == 0) "Nothing saved yet. New WhatsApp notifications will appear here."
                        else "No results for this search or filter."
                    )
                }
            }
            items(msgs, key = { it.id }) { m ->
                MessageCard(
                    m, showConversation = true,
                    modifier = Modifier.combinedClickable(
                        onClick = { vm.go(Screen.Conversation(m.convKey, m.convTitle)) },
                        onLongClick = { toDelete = m }
                    )
                )
            }
            item {
                Text(
                    "Tap a message to open the conversation. Press and hold to delete one record.",
                    fontSize = 12.sp, color = Color.Gray
                )
            }
        }
    }

    toDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete this record?") },
            text = { Text("It will be removed from this phone permanently.") },
            confirmButton = { TextButton(onClick = { vm.deleteRecord(m.id); toDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun Stat(label: String, value: Int, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(10.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value.toString(), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 12.sp)
        }
    }
}

@Composable
fun MessageCard(m: MessageEntity, showConversation: Boolean, modifier: Modifier = Modifier) {
    val who = if (m.groupName != null && showConversation) "${m.sender} · ${m.groupName}" else m.sender
    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(who, fontWeight = FontWeight.Bold)
                Text(fmt(m.capturedAt), fontSize = 12.sp, color = Color.Gray)
            }
            when (m.kind) {
                "DELETED" -> {
                    Text("Message deleted on WhatsApp", color = Red, fontWeight = FontWeight.Bold)
                    if (m.relatedText != null) {
                        Text("Original captured content:", fontSize = 12.sp, color = Color.Gray)
                        Text("\"${m.relatedText}\"")
                    } else {
                        Text("No earlier content was captured for this message.", fontSize = 13.sp, color = Color.Gray)
                    }
                }
                "CHANGED" -> {
                    Text("New notification version", color = Color(0xFF8A5A00), fontWeight = FontWeight.Bold)
                    Text("\"${m.text}\"")
                    if (m.relatedText != null) {
                        Text("Earlier version: \"${m.relatedText}\"", fontSize = 13.sp, color = Color.Gray)
                    }
                }
                else -> {
                    Text("\"${m.text}\"")
                    if (m.wasDeleted) Text("Later deleted on WhatsApp", fontSize = 12.sp, color = Red)
                    if (m.wasEdited) Text("Later changed (see newer version)", fontSize = 12.sp, color = Color(0xFF8A5A00))
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Conversation

@Composable
fun ConversationScreen(vm: VaultViewModel, s: Screen.Conversation) {
    val msgs by vm.convMessages.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<MessageEntity?>(null) }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(s.title) },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = { IconButton(onClick = { confirm = true }) { Icon(Icons.Default.Delete, "Delete conversation") } }
        )
    }) { pad ->
        LazyColumn(
            Modifier.padding(pad), contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("History, oldest first (time shown = when the notification was captured)", fontSize = 12.sp, color = Color.Gray) }
            items(msgs, key = { it.id }) { m ->
                MessageCard(m, showConversation = false, modifier = Modifier.combinedClickable(
                    onClick = {}, onLongClick = { toDelete = m }
                ))
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Delete this conversation?") },
        text = { Text("All saved records of \"${s.title}\" will be removed from this phone permanently.") },
        confirmButton = {
            TextButton(onClick = { vm.deleteConversation(s.key); confirm = false; vm.back() }) { Text("Delete") }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
    toDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete this record?") },
            text = { Text("It will be removed from this phone permanently.") },
            confirmButton = { TextButton(onClick = { vm.deleteRecord(m.id); toDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- Xiaomi / MIUI

@Composable
fun XiaomiScreen(vm: VaultViewModel, status: SystemStatus) {
    val ctx = LocalContext.current
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Xiaomi / MIUI Setup") },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Xiaomi phones close apps in the background to save battery. These 4 settings stop that for this app.")
            StatusLine("Notification access", status.accessGranted)
            StatusLine("Battery optimization turned off", status.batteryUnrestricted)
            Text("Autostart and \"No restrictions\" cannot be checked by the app. Please check them yourself.", fontSize = 13.sp, color = Color.Gray)

            Text("1. Autostart", fontWeight = FontWeight.Bold)
            Text("Switch ON for WhatsApp Message Vault, so it starts again after the phone restarts.")
            Button(onClick = {
                ctx.openFirst(
                    Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                    ctx.appDetails()
                )
            }, Modifier.fillMaxWidth()) { Text("Open Autostart") }

            Text("2. Battery saver: No restrictions", fontWeight = FontWeight.Bold)
            Text("Choose \"No restrictions\" for this app.")
            Button(onClick = {
                ctx.openFirst(
                    Intent().setComponent(ComponentName("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"))
                        .putExtra("package_name", ctx.packageName)
                        .putExtra("package_label", "WhatsApp Message Vault"),
                    ctx.appDetails()
                )
            }, Modifier.fillMaxWidth()) { Text("Open Battery saver") }

            Text("3. Battery optimization", fontWeight = FontWeight.Bold)
            Text("Find this app and choose \"Don't optimize\" / \"All apps\".")
            Button(onClick = {
                ctx.openFirst(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), ctx.appDetails())
            }, Modifier.fillMaxWidth()) { Text("Open battery optimization") }

            Text("4. Lock the app in Recent apps", fontWeight = FontWeight.Bold)
            Text("Open the Recent apps screen, press and hold the card of this app (or tap the small menu icon), then tap the padlock. This stops the phone from clearing it.")

            Text("Also: in your phone's Settings > Notifications, make sure WhatsApp notifications stay ON, because the app can only save what WhatsApp shows.", fontSize = 13.sp)
            OutlinedButton(onClick = { ctx.openFirst(ctx.appDetails()) }, Modifier.fillMaxWidth()) { Text("Open App info") }
            Button(onClick = { vm.back() }, Modifier.fillMaxWidth()) { Text("Done") }
        }
    }
}

// ---------------------------------------------------------------- Settings

@Composable
fun SettingsScreen(vm: VaultViewModel) {
    var confirm by remember { mutableStateOf(false) }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Settings") },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Button(onClick = { vm.go(Screen.Xiaomi) }, Modifier.fillMaxWidth()) { Text("Xiaomi / MIUI Setup") }
            OutlinedButton(onClick = { vm.restartSetup() }, Modifier.fillMaxWidth()) { Text("Run setup wizard again") }
            Button(
                onClick = { confirm = true }, Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Red)
            ) { Text("Delete all history") }
            Text("Privacy", fontWeight = FontWeight.Bold)
            Text("All data stays on this phone. The app has no internet permission, no account, no analytics and no ads.")
            Text("What this app can and cannot do", fontWeight = FontWeight.Bold)
            Text(
                "It saves the text WhatsApp shows in notifications, at the moment they appear. " +
                    "It cannot recover messages that never appeared as a notification (for example, messages you read " +
                    "inside WhatsApp while its notifications were hidden, or while this app was switched off). " +
                    "A \"changed\" or \"deleted\" label is a best guess from the notifications WhatsApp sent; " +
                    "if WhatsApp does not send a new notification for an edit or deletion, nothing can be detected."
            )
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Delete all history?") },
        text = { Text("Every saved message will be permanently removed from this phone. This cannot be undone.") },
        confirmButton = { TextButton(onClick = { vm.deleteAll(); confirm = false }) { Text("Delete everything") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
}
