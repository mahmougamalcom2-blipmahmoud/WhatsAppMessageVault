package com.vault.messagevault.service

import android.app.Notification
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.vault.messagevault.data.MessageDao
import com.vault.messagevault.data.MessageEntity
import java.text.SimpleDateFormat
import java.util.Locale

val WHATSAPP_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")

data class Draft(
    val pkg: String,
    val convKey: String,
    val convTitle: String,
    val groupName: String?,
    val sender: String,
    val title: String,
    val text: String,
    val msgTs: Long,
    val hasRealTs: Boolean,
    val category: String
)

object NotificationParser {
    private val countSuffix = Regex("\\s*\\(\\d+ (new )?messages?\\)$", RegexOption.IGNORE_CASE)
    private val generic = listOf(
        Regex("^\\d+ (new )?messages?( from \\d+ chats?)?$", RegexOption.IGNORE_CASE),
        Regex("^checking for new messages\\.*$", RegexOption.IGNORE_CASE),
        Regex("^whatsapp web is currently active$", RegexOption.IGNORE_CASE)
    )

    private fun clean(s: String) = s.replace(countSuffix, "").trim()
    private fun isGeneric(t: String) = generic.any { it.matches(t.trim()) }

    fun parse(sbn: StatusBarNotification): List<Draft> {
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return emptyList()
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return emptyList()
        val extras = n.extras
        val rawTitle = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val category = n.category ?: "message"
        val pkg = sbn.packageName
        val out = mutableListOf<Draft>()

        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        if (style != null && style.messages.isNotEmpty()) {
            val isGroup = style.isGroupConversation
            val convName = (style.conversationTitle?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: clean(rawTitle)).ifEmpty { "WhatsApp" }
            for (m in style.messages) {
                val text = m.text?.toString()?.trim().orEmpty()
                if (text.isEmpty() || isGeneric(text)) continue
                val person = m.person?.name?.toString()?.trim().orEmpty()
                val sender = person.ifEmpty { convName }
                out += Draft(
                    pkg, "$pkg|${convName.lowercase()}", convName, if (isGroup) convName else null,
                    sender, rawTitle, text,
                    if (m.timestamp > 0) m.timestamp else sbn.postTime,
                    m.timestamp > 0, category
                )
            }
            return out
        }

        // Fallback: plain notification without a message list.
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (text.isEmpty() || isGeneric(text)) return emptyList()
        var sender = clean(rawTitle)
        var group: String? = null
        if (" @ " in sender) {
            group = sender.substringAfter(" @ ").trim()
            sender = sender.substringBefore(" @ ").trim()
        }
        val conv = (group ?: sender).ifEmpty { "WhatsApp" }
        return listOf(
            Draft(pkg, "$pkg|${conv.lowercase()}", conv, group, sender.ifEmpty { conv },
                rawTitle, text, sbn.postTime, false, category)
        )
    }
}

object Recorder {
    private val deletedMarkers = listOf(
        "this message was deleted", "you deleted this message", "message deleted",
        "deleted this message", "ce message a été supprimé", "se eliminó este mensaje",
        "mensaje eliminado", "diese nachricht wurde gelöscht", "تم حذف هذه الرسالة"
    )
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun isDeletedNotice(text: String): Boolean {
        val t = text.lowercase()
        return deletedMarkers.any { it in t }
    }

    suspend fun record(dao: MessageDao, d: Draft) {
        val now = System.currentTimeMillis()
        if (dao.findExact(d.convKey, d.sender, d.text, d.msgTs) != null) return
        if (!d.hasRealTs) {
            val last = dao.latestInConv(d.convKey)
            if (last != null && last.text == d.text && last.sender == d.sender) return
        }
        val base = MessageEntity(
            packageName = d.pkg, convKey = d.convKey, convTitle = d.convTitle,
            groupName = d.groupName, sender = d.sender, title = d.title, text = d.text,
            msgTs = d.msgTs, capturedAt = now,
            dayKey = synchronized(dayFmt) { dayFmt.format(now) },
            category = d.category, kind = "NORMAL"
        )
        if (isDeletedNotice(d.text)) {
            val cand = (if (d.hasRealTs) dao.findByTs(d.convKey, d.sender, d.msgTs) else null)
                ?: dao.latestOriginal(d.convKey)
            if (cand != null) dao.markDeleted(cand.id)
            dao.insert(base.copy(kind = "DELETED", relatedId = cand?.id, relatedText = cand?.text))
            return
        }
        if (d.hasRealTs) {
            val prev = dao.findByTs(d.convKey, d.sender, d.msgTs)
            if (prev != null && prev.text != d.text) {
                dao.markEdited(prev.id)
                dao.insert(base.copy(kind = "CHANGED", relatedId = prev.id, relatedText = prev.text))
                return
            }
        }
        dao.insert(base)
    }
}
